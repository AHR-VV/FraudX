package linkshield

import java.io.IOException
import java.net.IDN
import java.net.URI
import java.net.URLDecoder
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse
import java.time.Duration
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Base64
import kotlin.math.abs

/*
 * Detector.kt - Explainable suspicious URL detection engine.
 *
 * The engine NEVER opens, requests or executes the submitted link. It only
 * parses the URL text and applies configurable heuristic rules. Each rule that
 * fires adds points to a 0-100 risk score and produces a plain-English reason.
 *
 * Optionally, if VT_API_KEY is configured, the URL string is looked up in
 * VirusTotal. A low score only means "no warning signs found" - it is NOT a
 * guarantee that a link is safe.
 */

const val DISCLAIMER =
    "A low score only means no warning signs were found by these automated rules. " +
        "It does NOT guarantee that a link is safe. Never enter passwords or " +
        "personal data on a site you do not fully trust."

private const val VT_API_BASE = "https://www.virustotal.com/api/v3"

class InvalidUrlException(message: String) : Exception(message)

// --------------------------------------------------------------------------- //
// Configuration (override any part by passing a DetectorConfig to UrlAnalyzer)
// --------------------------------------------------------------------------- //
data class Thresholds(val suspicious: Int = 30, val highRisk: Int = 60)

object Defaults {
    val weights: Map<String, Int> = mapOf(
        "ip_address" to 35,
        "obfuscated_ip" to 35,
        "no_https" to 15,
        "long_url" to 5,
        "very_long_url" to 10,
        "extreme_url" to 15,
        "at_symbol" to 25,
        "many_hyphens" to 8,
        "punycode" to 15,
        "non_ascii_host" to 15,
        "invalid_host_chars" to 12,
        "non_standard_port" to 8,
        "excessive_encoding" to 8,
        "special_symbols" to 8,
        "fake_https_token" to 10,
        "subdomains_moderate" to 8,
        "subdomains_excessive" to 15,
        "shortener" to 30,
        "typosquat" to 40,
        "brand_impersonation" to 30,
        "keyword_each" to 7,
        "keyword_cap" to 28,
        "suspicious_tld" to 12,
        "redirect_param" to 10,
        "executable_extension" to 20,
        "dangerous_scheme" to 90,
        // Threat intelligence (VirusTotal)
        "ti_malicious_base" to 40,
        "ti_malicious_per_engine" to 5,
        "ti_malicious_cap" to 70,
        "ti_suspicious" to 15,
    )

    val shorteners: Set<String> = setOf(
        "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly",
        "rebrand.ly", "cutt.ly", "shorturl.at", "tiny.cc", "rb.gy", "bl.ink",
        "t.ly", "lnkd.in", "s.id", "v.gd", "adf.ly", "bit.do", "shorte.st",
        "soo.gd", "mcaf.ee", "qr.ae", "tr.im", "short.io",
    )

    val keywords: List<String> = listOf(
        "login", "signin", "sign-in", "verify", "verification", "password",
        "passwd", "account", "secure", "security", "update", "confirm",
        "banking", "wallet", "suspend", "unlock", "billing", "payment",
        "credential", "authenticate", "recover", "reset", "bonus", "prize",
        "claim", "urgent",
    )

    val suspiciousTlds: Set<String> = setOf(
        "zip", "mov", "xyz", "top", "tk", "ml", "ga", "cf", "gq", "click",
        "link", "work", "support", "country", "kim", "loan", "men", "review",
        "icu", "cyou", "rest", "buzz", "monster",
    )

    val executableExtensions: List<String> = listOf(
        ".exe", ".scr", ".bat", ".cmd", ".msi", ".apk", ".vbs", ".jar",
        ".ps1", ".dmg", ".iso", ".lnk",
    )

    /** brand keyword -> registered domains that legitimately belong to it */
    val brands: Map<String, Set<String>> = mapOf(
        "paypal" to setOf("paypal.com", "paypal.me", "paypalobjects.com"),
        "google" to setOf(
            "google.com", "google.co.in", "google.co.uk", "googleapis.com",
            "gstatic.com", "googleusercontent.com", "goo.gl", "youtube.com",
            "gmail.com", "withgoogle.com",
        ),
        "microsoft" to setOf(
            "microsoft.com", "live.com", "office.com", "office365.com",
            "microsoftonline.com", "outlook.com", "windows.com", "azure.com",
            "bing.com", "msn.com", "sharepoint.com", "skype.com", "xbox.com",
        ),
        "apple" to setOf("apple.com", "icloud.com", "me.com"),
        "amazon" to setOf(
            "amazon.com", "amazon.in", "amazon.co.uk", "amazon.de",
            "amazon.ca", "amazonaws.com",
        ),
        "facebook" to setOf(
            "facebook.com", "fb.com", "fb.me", "facebook.net", "fbcdn.net", "messenger.com",
        ),
        "instagram" to setOf("instagram.com"),
        "whatsapp" to setOf("whatsapp.com", "whatsapp.net", "wa.me"),
        "netflix" to setOf("netflix.com", "nflxso.net", "nflximg.net"),
        "linkedin" to setOf("linkedin.com", "licdn.com", "lnkd.in"),
        "twitter" to setOf("twitter.com", "t.co", "x.com"),
        "dropbox" to setOf("dropbox.com", "dropboxusercontent.com"),
        "github" to setOf("github.com", "github.io", "githubusercontent.com"),
        "paytm" to setOf("paytm.com"),
        "steam" to setOf("steampowered.com", "steamcommunity.com"),
        "adobe" to setOf("adobe.com"),
        "docusign" to setOf("docusign.com", "docusign.net"),
        "binance" to setOf("binance.com"),
        "coinbase" to setOf("coinbase.com"),
        "telegram" to setOf("telegram.org", "t.me"),
        "wellsfargo" to setOf("wellsfargo.com"),
        "bankofamerica" to setOf("bankofamerica.com"),
    )
}

/** Any property can be overridden; missing weights fall back to [Defaults.weights]. */
data class DetectorConfig(
    val thresholds: Thresholds = Thresholds(),
    val maxInputLength: Int = 2048,
    val lengthLong: Int = 75,
    val lengthVeryLong: Int = 120,
    val lengthExtreme: Int = 200,
    val subdomainsModerate: Int = 3,
    val subdomainsExcessive: Int = 4,
    val weights: Map<String, Int> = Defaults.weights,
    val shorteners: Set<String> = Defaults.shorteners,
    val keywords: List<String> = Defaults.keywords,
    val suspiciousTlds: Set<String> = Defaults.suspiciousTlds,
    val executableExtensions: List<String> = Defaults.executableExtensions,
    val brands: Map<String, Set<String>> = Defaults.brands,
)

private val MULTI_PART_SUFFIXES = setOf(
    "co.uk", "org.uk", "ac.uk", "gov.uk", "com.au", "net.au", "org.au",
    "co.in", "net.in", "org.in", "co.jp", "com.br", "co.nz", "co.za",
    "com.cn", "com.sg", "com.mx",
)

/** Look-alike characters used in typosquatting / homograph attacks. */
private val CONFUSABLES = mapOf(
    '\u0430' to 'a', '\u0435' to 'e', '\u043e' to 'o', '\u0440' to 'p',
    '\u0441' to 'c', '\u0445' to 'x', '\u0456' to 'i', '\u0455' to 's',
    '\u0458' to 'j', '\u0501' to 'd', '\u04bb' to 'h', '\u03bf' to 'o',
    '\u03bd' to 'v', '\u0261' to 'g',
)
private val LEET = mapOf('0' to 'o', '3' to 'e', '4' to 'a', '5' to 's', '7' to 't', '$' to 's', '@' to 'a')

private val DANGEROUS_SCHEMES = listOf("javascript:", "data:", "vbscript:", "file:")
private val ALLOWED_SCHEMES = setOf("http", "https", "ftp")

private val SCHEME_RE = Regex("^[a-z][a-z0-9+.\\-]*://", RegexOption.IGNORE_CASE)
private val URL_RE = Regex("^([a-z][a-z0-9+.\\-]*)://([^/?#]*)([^?#]*)(?:\\?([^#]*))?(?:#.*)?$", RegexOption.IGNORE_CASE)
private val NUMERIC_HOST_RE = Regex("(0x[0-9a-f]+|\\d+)(\\.(0x[0-9a-f]+|\\d+)){0,3}")
private val VALID_HOST_RE = Regex("[a-z0-9.\\-]+")
private val IPV6_RE = Regex("[0-9a-f:.]+")
private val SPECIAL_SYMBOLS_RE = Regex("""[!${'$'}*()\[\]{}|\\<>`;^]""")
private val PERCENT_RE = Regex("%[0-9a-fA-F]{2}")
private val REDIRECT_RE = Regex("https?(?::|%3a)(?:/|%2f){2}")

// --------------------------------------------------------------------------- //
// Result data structures
// --------------------------------------------------------------------------- //
data class Finding(val ruleId: String, val title: String, val points: Int, val description: String)

data class ThreatIntelResult(
    val status: String = "disabled", // disabled | ok | not_found | error
    val malicious: Int = 0,
    val suspicious: Int = 0,
    val harmless: Int = 0,
    val undetected: Int = 0,
    val message: String = "",
) {
    fun summary(): String = when (status) {
        "ok" -> "VirusTotal: $malicious malicious, $suspicious suspicious, " +
            "$harmless harmless, $undetected undetected"
        "not_found" -> "VirusTotal: $message"
        "error" -> "VirusTotal: lookup failed - $message"
        else -> "Threat intelligence not used (${message.ifBlank { "disabled" }})"
    }
}

data class ScanResult(
    val originalInput: String,
    val normalizedUrl: String,
    val hostname: String,
    val score: Int,
    val classification: String,
    val findings: List<Finding>,
    val threatIntel: ThreatIntelResult,
    val scannedAt: String,
) {
    /** Plain-text report suitable for copying and pasting. */
    fun toReport(): String = buildString {
        val line = "=".repeat(64)
        appendLine(line)
        appendLine("SUSPICIOUS LINK DETECTION REPORT")
        appendLine(line)
        appendLine("Scanned at     : $scannedAt")
        appendLine("URL analysed   : $normalizedUrl")
        appendLine("Domain / host  : $hostname")
        appendLine("Risk score     : $score / 100")
        appendLine("Classification : $classification")
        appendLine()
        appendLine("Why this result was produced:")
        if (findings.isEmpty()) {
            appendLine("  - No suspicious characteristics were detected by the rules.")
        } else {
            findings.forEachIndexed { i, f ->
                appendLine("  ${i + 1}. [+${f.points}] ${f.title}")
                appendLine("       ${f.description}")
            }
        }
        appendLine()
        appendLine(threatIntel.summary())
        appendLine()
        appendLine("Note: $DISCLAIMER")
        append(line)
    }
}

fun classify(score: Int, t: Thresholds = Thresholds()): String = when {
    score >= t.highRisk -> "High Risk"
    score >= t.suspicious -> "Suspicious"
    else -> "Low Risk"
}

// --------------------------------------------------------------------------- //
// Environment / .env support (no external library needed)
// --------------------------------------------------------------------------- //
object Env {
    private val fileVars: Map<String, String> by lazy {
        try {
            java.io.File(".env").readLines()
                .map { it.trim() }
                .filter { it.isNotEmpty() && !it.startsWith("#") && it.contains("=") }
                .associate {
                    it.substringBefore("=").trim() to
                        it.substringAfter("=").trim().trim('"', '\'')
                }
        } catch (e: IOException) {
            emptyMap()
        }
    }

    fun get(key: String): String = (System.getenv(key) ?: fileVars[key] ?: "").trim()
    fun apiKey(): String = get("VT_API_KEY").takeIf { !it.startsWith("your_") } ?: ""
}

// --------------------------------------------------------------------------- //
// Optional threat intelligence (VirusTotal v3, JDK HTTP client only)
// --------------------------------------------------------------------------- //
data class HttpReply(val status: Int, val body: String)

/** Small interface so tests can inject fake network replies. */
fun interface VtHttp {
    @Throws(IOException::class)
    fun get(url: String, apiKey: String, timeoutSec: Long): HttpReply
}

object DefaultVtHttp : VtHttp {
    private val client: HttpClient by lazy {
        HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build()
    }

    override fun get(url: String, apiKey: String, timeoutSec: Long): HttpReply {
        val request = HttpRequest.newBuilder(URI.create(url))
            .timeout(Duration.ofSeconds(timeoutSec))
            .header("x-apikey", apiKey)
            .header("accept", "application/json")
            .GET()
            .build()
        val response = client.send(request, HttpResponse.BodyHandlers.ofString())
        return HttpReply(response.statusCode(), response.body())
    }
}

/** Looks the URL up in VirusTotal. Never throws - problems are returned as a status. */
fun checkVirusTotal(
    url: String,
    apiKey: String,
    timeoutSec: Long = 10,
    http: VtHttp = DefaultVtHttp,
): ThreatIntelResult {
    if (apiKey.isBlank()) return ThreatIntelResult(status = "disabled", message = "no API key configured")
    val id = Base64.getUrlEncoder().withoutPadding().encodeToString(url.toByteArray(Charsets.UTF_8))
    return try {
        val reply = http.get("$VT_API_BASE/urls/$id", apiKey, timeoutSec)
        when (reply.status) {
            200 -> parseVtStats(reply.body)
            404 -> ThreatIntelResult(
                status = "not_found",
                message = "this URL has not been analysed before (not proof of safety)",
            )
            401 -> ThreatIntelResult(status = "error", message = "invalid API key")
            403 -> ThreatIntelResult(status = "error", message = "access denied")
            429 -> ThreatIntelResult(status = "error", message = "rate limit reached")
            else -> ThreatIntelResult(status = "error", message = "HTTP error ${reply.status}")
        }
    } catch (e: IOException) { // includes timeouts
        ThreatIntelResult(status = "error", message = "network error or timeout")
    } catch (e: InterruptedException) {
        Thread.currentThread().interrupt()
        ThreatIntelResult(status = "error", message = "lookup interrupted")
    }
}

private fun parseVtStats(body: String): ThreatIntelResult {
    val block = Regex("\"last_analysis_stats\"\\s*:\\s*\\{([^}]*)\\}").find(body)?.groupValues?.get(1)
        ?: return ThreatIntelResult(status = "error", message = "unexpected response format")
    fun stat(name: String): Int =
        Regex("\"$name\"\\s*:\\s*(\\d+)").find(block)?.groupValues?.get(1)?.toIntOrNull() ?: 0
    return ThreatIntelResult(
        status = "ok",
        malicious = stat("malicious"),
        suspicious = stat("suspicious"),
        harmless = stat("harmless"),
        undetected = stat("undetected"),
    )
}

// --------------------------------------------------------------------------- //
// Helpers
// --------------------------------------------------------------------------- //
/** Returns (subdomain labels, registered domain). */
fun splitHost(host: String): Pair<List<String>, String> {
    val labels = host.split(".")
    val keep = if (labels.size >= 3 && labels.takeLast(2).joinToString(".") in MULTI_PART_SUFFIXES) 3 else 2
    if (labels.size <= keep) return emptyList<String>() to host
    return labels.dropLast(keep) to labels.takeLast(keep).joinToString(".")
}

private fun skeletonVariants(token: String): List<String> {
    var t = token.map { CONFUSABLES[it] ?: it }.joinToString("")
    t = t.map { LEET[it] ?: it }.joinToString("").replace("rn", "m").replace("vv", "w")
    return listOf(t.replace('1', 'l'), t.replace('1', 'i'))
}

private fun levenshtein(a: String, b: String): Int {
    var prev = IntArray(b.length + 1) { it }
    for (i in 1..a.length) {
        val cur = IntArray(b.length + 1)
        cur[0] = i
        for (j in 1..b.length) {
            val cost = if (a[i - 1] == b[j - 1]) 0 else 1
            cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
        }
        prev = cur
    }
    return prev[b.length]
}

private fun similarity(a: String, b: String): Double {
    val maxLen = maxOf(a.length, b.length)
    return if (maxLen == 0) 1.0 else 1.0 - levenshtein(a, b).toDouble() / maxLen
}

private fun String.urlDecoded(): String =
    try { URLDecoder.decode(this, Charsets.UTF_8) } catch (e: IllegalArgumentException) { this }

private fun isIPv4(host: String): Boolean {
    val parts = host.split(".")
    return parts.size == 4 && parts.all { p ->
        p.isNotEmpty() && p.length <= 3 && p.all { it in '0'..'9' } &&
            (p == "0" || !p.startsWith("0")) && p.toInt() <= 255
    }
}

private fun isIPv6(host: String): Boolean =
    host.count { it == ':' } >= 2 && IPV6_RE.matches(host)

private fun parsePort(text: String): Int? {
    if (text.isEmpty()) return null
    if (!text.all { it in '0'..'9' } || text.length > 5) throw InvalidUrlException("Malformed URL: invalid port.")
    val port = text.toInt()
    if (port > 65535) throw InvalidUrlException("Malformed URL: port out of range.")
    return port
}

/** Parsed pieces of a URL shared by all rule checks. */
private data class Ctx(
    val url: String,
    val scheme: String,
    val host: String,          // ASCII (punycode) form
    val unicodeHost: String,   // human-readable form
    val port: Int?,
    val path: String,
    val query: String,
    val netloc: String,
    val isIp: Boolean,
    val isObfuscatedIp: Boolean,
    val subdomains: List<String>,
    val registered: String,
    val assumedScheme: Boolean,
    val hostWasNonAscii: Boolean,
) {
    val numericHost: Boolean get() = isIp || isObfuscatedIp
}

// --------------------------------------------------------------------------- //
// The analyzer
// --------------------------------------------------------------------------- //
class UrlAnalyzer(private val config: DetectorConfig = DetectorConfig()) {

    private val weights = Defaults.weights + config.weights
    private fun w(key: String): Int = weights.getValue(key)

    private val rules: List<(Ctx) -> List<Finding>> = listOf(
        this::checkIp, this::checkHttps, this::checkLength, this::checkSymbols,
        this::checkSubdomains, this::checkShortener, this::checkBrand,
        this::checkKeywords, this::checkTld, this::checkRedirect, this::checkExtension,
    )

    /** Analyze a URL string and return an explainable [ScanResult]. */
    fun analyze(
        rawUrl: String?,
        useThreatIntel: Boolean = true,
        apiKey: String? = null,
        http: VtHttp = DefaultVtHttp,
    ): ScanResult {
        if (rawUrl == null || rawUrl.isBlank()) throw InvalidUrlException("Please enter a URL to scan.")
        val raw = rawUrl.trim()
        val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))

        // Dangerous pseudo-schemes are reported directly (never executed)
        if (DANGEROUS_SCHEMES.any { raw.lowercase().startsWith(it) }) {
            val scheme = raw.substringBefore(":").lowercase()
            val finding = Finding(
                "dangerous_scheme", "Dangerous '$scheme:' link", w("dangerous_scheme"),
                "'$scheme:' links can run code or expose local data instead of opening a " +
                    "normal website. Do not open or paste them anywhere.",
            )
            val score = minOf(100, finding.points)
            return ScanResult(
                raw, raw, scheme, score, classify(score, config.thresholds), listOf(finding),
                ThreatIntelResult(message = "not applicable"), stamp,
            )
        }

        val ctx = buildContext(raw)
        val findings = rules.flatMap { it(ctx) }.toMutableList()

        var ti = ThreatIntelResult(message = "disabled by user")
        if (useThreatIntel) {
            val key = apiKey ?: Env.apiKey()
            val timeout = Env.get("VT_TIMEOUT").toLongOrNull() ?: 10L
            ti = checkVirusTotal(ctx.url, key, timeout, http)
            findings += threatIntelFindings(ti)
        }

        var score = minOf(100, findings.sumOf { it.points })
        // A confirmed detection by security vendors overrides the heuristics
        if (ti.status == "ok" && ti.malicious >= 3) score = maxOf(score, config.thresholds.highRisk)
        else if (ti.status == "ok" && ti.malicious >= 1) score = maxOf(score, config.thresholds.suspicious)

        return ScanResult(
            raw, ctx.url, ctx.unicodeHost, score, classify(score, config.thresholds),
            findings.sortedByDescending { it.points }, ti, stamp,
        )
    }

    /** Validates input and adds a scheme if missing. Returns (url, schemeWasAssumed). */
    fun normalize(raw: String): Pair<String, Boolean> {
        val url = raw.trim()
        if (url.isEmpty()) throw InvalidUrlException("Please enter a URL to scan.")
        if (url.length > config.maxInputLength) {
            throw InvalidUrlException("Input is too long (max ${config.maxInputLength} characters).")
        }
        if (url.any { it.isWhitespace() }) throw InvalidUrlException("A URL cannot contain spaces or line breaks.")
        if (SCHEME_RE.containsMatchIn(url)) {
            val scheme = url.substringBefore("://").lowercase()
            if (scheme !in ALLOWED_SCHEMES) {
                throw InvalidUrlException(
                    "Unsupported scheme '$scheme://'. Only http, https and ftp links can be analysed.",
                )
            }
            return url to false
        }
        return "http://$url" to true
    }

    // ----------------------------- parsing --------------------------------- //
    private fun buildContext(raw: String): Ctx {
        val (url, assumed) = normalize(raw)
        val m = URL_RE.matchEntire(url) ?: throw InvalidUrlException("Malformed URL.")
        val scheme = m.groupValues[1].lowercase()
        val netloc = m.groupValues[2]
        val path = m.groupValues[3]
        val query = m.groups[4]?.value ?: ""

        val hostPort = netloc.substringAfterLast('@')
        val hostRaw: String
        var port: Int? = null
        if (hostPort.startsWith("[")) {
            val end = hostPort.indexOf(']')
            if (end < 0) throw InvalidUrlException("Malformed URL: invalid IPv6 address.")
            hostRaw = hostPort.substring(1, end)
            val rest = hostPort.substring(end + 1)
            if (rest.isNotEmpty()) {
                if (!rest.startsWith(":")) throw InvalidUrlException("Malformed URL.")
                port = parsePort(rest.substring(1))
            }
        } else {
            val idx = hostPort.lastIndexOf(':')
            if (idx >= 0) {
                hostRaw = hostPort.substring(0, idx)
                port = parsePort(hostPort.substring(idx + 1))
            } else {
                hostRaw = hostPort
            }
        }

        var host = hostRaw.lowercase().trimEnd('.')
        if (host.isEmpty()) throw InvalidUrlException("No domain name or IP address found in the URL.")

        val wasNonAscii = host.any { it.code > 127 }
        if (wasNonAscii) {
            host = try {
                IDN.toASCII(host)
            } catch (e: IllegalArgumentException) {
                throw InvalidUrlException("The domain name contains invalid characters.")
            }
        }

        val isIp = isIPv4(host) || isIPv6(host)
        val isObfuscated = !isIp && NUMERIC_HOST_RE.matches(host)

        if (!isIp && !isObfuscated) {
            val labels = host.split(".")
            if (host.length > 253 || labels.any { it.isEmpty() }) {
                throw InvalidUrlException("The domain name is not valid.")
            }
            if (labels.size < 2 && host != "localhost") {
                throw InvalidUrlException("The domain must contain a dot (for example: example.com).")
            }
        }

        val (subdomains, registered) =
            if (isIp || isObfuscated) emptyList<String>() to host else splitHost(host)

        return Ctx(
            url = url, scheme = scheme, host = host, unicodeHost = IDN.toUnicode(host),
            port = port, path = path, query = query, netloc = netloc, isIp = isIp,
            isObfuscatedIp = isObfuscated, subdomains = subdomains, registered = registered,
            assumedScheme = assumed, hostWasNonAscii = wasNonAscii,
        )
    }

    // ------------------------------- rules --------------------------------- //
    private fun checkIp(c: Ctx): List<Finding> = when {
        c.isIp -> listOf(
            Finding(
                "ip_address", "IP address used instead of a domain name", w("ip_address"),
                "The link points to the raw address ${c.host}. Legitimate services almost " +
                    "always use a registered domain name.",
            ),
        )
        c.isObfuscatedIp -> listOf(
            Finding(
                "obfuscated_ip", "Obfuscated numeric IP address", w("obfuscated_ip"),
                "'${c.host}' is a disguised IP address written in decimal, hex or octal " +
                    "form - a trick used to hide the real destination.",
            ),
        )
        else -> emptyList()
    }

    private fun checkHttps(c: Ctx): List<Finding> {
        if (c.scheme == "https") return emptyList()
        val extra = if (c.assumedScheme) " No scheme was entered, so HTTP was assumed." else ""
        return listOf(
            Finding(
                "no_https", "Connection is not encrypted (no HTTPS)", w("no_https"),
                "The link uses '${c.scheme}' instead of HTTPS, so data sent to the site " +
                    "can be read or modified in transit.$extra",
            ),
        )
    }

    private fun checkLength(c: Ctx): List<Finding> {
        val n = c.url.length
        val (key, label) = when {
            n >= config.lengthExtreme -> "extreme_url" to "Extremely long URL"
            n >= config.lengthVeryLong -> "very_long_url" to "Very long URL"
            n >= config.lengthLong -> "long_url" to "Long URL"
            else -> return emptyList()
        }
        return listOf(
            Finding(
                key, label, w(key),
                "The URL is $n characters long. Attackers use long URLs to hide the real " +
                    "domain or bury malicious parameters.",
            ),
        )
    }

    private fun checkSymbols(c: Ctx): List<Finding> {
        val out = mutableListOf<Finding>()
        if ('@' in c.netloc) {
            out += Finding(
                "at_symbol", "'@' symbol before the domain", w("at_symbol"),
                "Everything before '@' is ignored by the browser, so the link can look " +
                    "like a trusted site while going somewhere else.",
            )
        }
        if (c.hostWasNonAscii) {
            out += Finding(
                "non_ascii_host", "Non-English characters in the domain", w("non_ascii_host"),
                "The domain uses look-alike (homograph) characters that can imitate a trusted name.",
            )
        } else if (c.host.split(".").any { it.startsWith("xn--") }) {
            out += Finding(
                "punycode", "Punycode (internationalised) domain", w("punycode"),
                "The domain is encoded as punycode and decodes to '${c.unicodeHost}'. " +
                    "Punycode is often used for look-alike domains.",
            )
        }
        if (!c.numericHost) {
            if (!VALID_HOST_RE.matches(c.host)) {
                out += Finding(
                    "invalid_host_chars", "Unusual characters in the domain", w("invalid_host_chars"),
                    "The domain contains characters that are not normally valid in hostnames.",
                )
            }
            val hyphens = c.host.count { it == '-' }
            if (hyphens >= 3) {
                out += Finding(
                    "many_hyphens", "Many hyphens in the domain", w("many_hyphens"),
                    "The domain has $hyphens hyphens, a common pattern in throw-away phishing domains.",
                )
            }
            if (Regex("https?").containsMatchIn(c.host.substringBefore("."))) {
                out += Finding(
                    "fake_https_token", "'http(s)' written inside the domain", w("fake_https_token"),
                    "The word 'https' appears in the domain name to look secure, but it is " +
                        "not the real protocol.",
                )
            }
        }
        val port = c.port
        if (port != null && port != 80 && port != 443) {
            out += Finding(
                "non_standard_port", "Non-standard port ($port)", w("non_standard_port"),
                "Legitimate public websites rarely use unusual ports.",
            )
        }
        if (PERCENT_RE.findAll(c.url).count() > 5 || "%25" in c.url) {
            out += Finding(
                "excessive_encoding", "Heavy percent-encoding", w("excessive_encoding"),
                "Lots of %XX-encoded characters can hide the true content of the link.",
            )
        }
        val specials = SPECIAL_SYMBOLS_RE.findAll(c.path + c.query).count()
        if (specials >= 3) {
            out += Finding(
                "special_symbols", "Suspicious symbols in the URL", w("special_symbols"),
                "$specials unusual symbols were found in the path or query (e.g. < > { } | ; \$).",
            )
        }
        return out
    }

    private fun checkSubdomains(c: Ctx): List<Finding> {
        if (c.numericHost) return emptyList()
        val subs = if (c.subdomains.firstOrNull() == "www") c.subdomains.drop(1) else c.subdomains
        val n = subs.size
        val (key, label) = when {
            n >= config.subdomainsExcessive -> "subdomains_excessive" to "Excessive number of subdomains"
            n >= config.subdomainsModerate -> "subdomains_moderate" to "Many subdomains"
            else -> return emptyList()
        }
        return listOf(
            Finding(
                key, label, w(key),
                "The host has $n subdomain levels (${subs.joinToString(".")}). The real owner " +
                    "of the site is the last part: '${c.registered}'. Long subdomain chains " +
                    "are used to push the real domain out of view.",
            ),
        )
    }

    private fun checkShortener(c: Ctx): List<Finding> {
        if (c.numericHost) return emptyList()
        if (c.host in config.shorteners || c.registered in config.shorteners) {
            return listOf(
                Finding(
                    "shortener", "URL shortener service", w("shortener"),
                    "'${c.registered}' is a link-shortening service, so the real destination " +
                        "is hidden until you click. Expand the link with a safe previewing tool first.",
                ),
            )
        }
        return emptyList()
    }

    private fun checkBrand(c: Ctx): List<Finding> {
        if (c.numericHost) return emptyList()
        val tokens = c.unicodeHost.lowercase().split(Regex("[.\\-_]+")).filter { it.isNotEmpty() }
        val out = mutableListOf<Finding>()
        for ((brand, legit) in config.brands) {
            if (c.registered in legit) continue
            var typo: String? = null
            var imp: String? = null
            for (token in tokens) {
                val variants = skeletonVariants(token)
                if (token == brand) {
                    if (imp == null) imp = token
                } else if (variants.any { it == brand }) {
                    typo = token
                    break
                } else if (token.length >= 5 && abs(token.length - brand.length) <= 2 &&
                    (variants + token).any { similarity(it, brand) >= 0.85 }
                ) {
                    typo = token
                    break
                } else if (brand.length >= 6 && (token.startsWith(brand) || token.endsWith(brand))) {
                    if (imp == null) imp = token
                }
            }
            val brandName = brand.replaceFirstChar { it.uppercase() }
            if (typo != null) {
                out += Finding(
                    "typosquat", "Misspelled / look-alike domain imitating '$brand'", w("typosquat"),
                    "'$typo' looks like a deliberate misspelling or character swap of '$brand', " +
                        "but the real domain is '${c.registered}', which does not belong to $brandName.",
                )
            } else if (imp != null) {
                out += Finding(
                    "brand_impersonation", "Misleading use of the '$brand' name", w("brand_impersonation"),
                    "The name '$brand' appears in the link, but the site actually belongs to " +
                        "'${c.registered}', not to $brandName.",
                )
            }
        }
        return out
    }

    private fun checkKeywords(c: Ctx): List<Finding> {
        val text = (c.unicodeHost + c.path + "?" + c.query).urlDecoded().lowercase()
        val found = config.keywords.filter { it in text }
        if (found.isEmpty()) return emptyList()
        val points = minOf(found.size * w("keyword_each"), w("keyword_cap"))
        return listOf(
            Finding(
                "keywords", "Suspicious keywords", points,
                "The URL contains words often used in phishing lures: ${found.joinToString(", ")}.",
            ),
        )
    }

    private fun checkTld(c: Ctx): List<Finding> {
        if (c.numericHost) return emptyList()
        val tld = c.host.substringAfterLast(".")
        if (tld in config.suspiciousTlds) {
            return listOf(
                Finding(
                    "suspicious_tld", "Risky top-level domain (.$tld)", w("suspicious_tld"),
                    "The '.$tld' ending is cheap or free to register and is frequently abused " +
                        "for spam and phishing.",
                ),
            )
        }
        return emptyList()
    }

    private fun checkRedirect(c: Ctx): List<Finding> {
        if (REDIRECT_RE.containsMatchIn((c.path + "?" + c.query).lowercase())) {
            return listOf(
                Finding(
                    "redirect_param", "Another URL embedded in the link", w("redirect_param"),
                    "The link carries a second web address inside its path or parameters, " +
                        "which is typical of open-redirect abuse.",
                ),
            )
        }
        return emptyList()
    }

    private fun checkExtension(c: Ctx): List<Finding> {
        val path = c.path.urlDecoded().lowercase()
        val ext = config.executableExtensions.firstOrNull { path.endsWith(it) } ?: return emptyList()
        return listOf(
            Finding(
                "executable_extension", "Link to a '$ext' file", w("executable_extension"),
                "The link points directly to a program or installer, which could be malware.",
            ),
        )
    }

    private fun threatIntelFindings(ti: ThreatIntelResult): List<Finding> {
        if (ti.status != "ok") return emptyList()
        if (ti.malicious > 0) {
            val pts = minOf(
                w("ti_malicious_base") + w("ti_malicious_per_engine") * ti.malicious,
                w("ti_malicious_cap"),
            )
            return listOf(
                Finding(
                    "ti_malicious", "Flagged as malicious by threat intelligence", pts,
                    "${ti.malicious} security vendor(s) on VirusTotal classify this URL as malicious.",
                ),
            )
        }
        if (ti.suspicious > 0) {
            return listOf(
                Finding(
                    "ti_suspicious", "Flagged as suspicious by threat intelligence", w("ti_suspicious"),
                    "${ti.suspicious} security vendor(s) on VirusTotal classify this URL as suspicious.",
                ),
            )
        }
        return emptyList()
    }
}

/** Convenience wrapper using the default configuration. */
fun analyzeUrl(url: String, useThreatIntel: Boolean = true): ScanResult =
    UrlAnalyzer().analyze(url, useThreatIntel)
